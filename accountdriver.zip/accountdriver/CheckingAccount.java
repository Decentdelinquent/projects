/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package accountdriver;

/**
 *
 * @author layla
 */
public class CheckingAccount extends BankAccount {
    
    private static double fee=.15;
    public CheckingAccount(String name, double amount) {
    
    super(name,amount);
    
    setAccountNumber(getAccountNumber()+"-10");
    
    }
    
    public boolean withdraw(double amount){
    
        amount=amount-fee;
        
        return super.withdraw(amount);
    
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package accountdriver;

/**
 *
 * @author layla
 */
public class SavingsAccount extends BankAccount {
    
   private double rate=.025;
   private int savingAccount=0;
   private String accountNumber;
   
   public SavingsAccount(String name,double Amount){
       
   super(name,Amount);
   accountNumber=super.getAccountNumber()+ "-"+savingAccount;
   
   }
   
   
   public SavingsAccount (SavingsAccount OldAccount, double Amount) {
       super(OldAccount , Amount);
       savingAccount=OldAccount.savingAccount +1;
       accountNumber=super.getAccountNumber()+ "-"+savingAccount;
   
   
   }
    public void postInterest(){
        double newBalance=getBalance()*(1+rate/12);
        setBalance(newBalance);
    }
    public String getAccountNumber()
   {
      return accountNumber;
   }
    
}


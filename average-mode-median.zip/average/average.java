/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package average;

import java.util.Scanner;



/**
 * 
 * @author layla & razan
 * This class calculates the mean, mode, and median of a 5 element array for test scores out of 100
 */

public class average {
    
    //variables declaration, intialization/assignment
    public double[] data;
    public double mean, median,mode;
    public int maxLength;
    
    //constructor takes array values from user input
    public average(){
        
        
        Scanner kb=new Scanner(System.in);
        System.out.print("Enter number of students:");
        maxLength=kb.nextInt();
        
        if(maxLength==0){
        System.out.print("No students entered, thanks for using our application.");
        System.exit(0);
        }
            
            
        while(maxLength<0){
                    
                 System.out.print("Wrong input value, Please enter positive number:");
                 maxLength=kb.nextInt();
                
            }
        
        
        
        data=new double[maxLength];
        
        for(int i=0;i<data.length;i++) {
            System.out.print("Enter score number out of 100 for student #"+(i+1)+":");
            data[i]=kb.nextDouble();
            
            while(data[i] < 0 || data[i] > 100){
                    
                 System.out.print("Wrong input value, Please enter a score out of 100 for student #"+(i+1)+":");
                 data[i]=kb.nextDouble();
                
            }
            
            
        }
    }
    
   //sorts array elemnts from largest to smallest 
   public double[] selectionSort(double array[])
   {  
   array=data;
       double temp;
    for(int i=0;i<data.length;i++){
    
    for(int j=i;j<data.length;j++){
    if(data[i]>data[j]){
        
        temp=data[i];
        data[i]=data[j];
        data[j]=temp;
    }
    }
    }
    
    return data;
    }
    
   /**
    * 
    * @return mean of the array
    */
    public double calculateMean(){
    double total=0;
    for (int i=0;i<data.length;i++){
    
        total=total+data[i];   
    }
    mean=total/data.length;
    return mean;
    }
    
    /**
     * 
     * @return mode of array
     */
    public double calculateMode() {
      double maxValue = 0, maxCount = 0;
      int i, j;

      for (i = 0; i < data.length; ++i) {
         int count = 0;
         for (j = 0; j < data.length; ++j) {
            if (data[j] == data[i])
            ++count;
         }

         if (count > maxCount) {
            maxCount = count;
            maxValue = data[i];
         }
      }
      mode=maxValue;
      return mode;
   }
   
    /**
     * 
     * @return median of array
     * 
     * */
  
    public double calculateMedian(){
    
    if(data.length%2==1)
     {
    median=data[(data.length+1)/2-1];
    }
  else
  {
    median=(data[data.length/2-1]+data[data.length/2])/2;
  }
      return median; 
    }

    public String toString(){
    
       String output="\n the test score are: \n";
             
      for(int i=0;i<data.length;i++){
      output =output + " " + data[i];
      }
             
      output = output+"\n"+"\n"+ "Mean= "+mean+"\n"+"Mode= "+mode+"\n"+"Median= "+median;
      return output;

    }
    
     public static void main(String[] args) {
        
        average a=new average();
        
        a.selectionSort(a.data);
        a.calculateMean();
        a.calculateMode();
        a.calculateMedian();
    
        System.out.println(a.toString());
    }
}



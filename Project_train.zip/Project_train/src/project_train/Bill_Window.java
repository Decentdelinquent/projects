
package project_train;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.border.TitledBorder;

public class Bill_Window extends JFrame {
    
    private JPanel Bill_p=new JPanel();
    private JPanel header_p = new JPanel();
    private JPanel chosen_p = new JPanel();
    private JPanel all_p = new JPanel();
    private JPanel total_p = new JPanel();
    private JPanel big_p = new JPanel();
    private JPanel button_p = new JPanel();
    private JLabel train_l =new JLabel("Train");
    private JLabel quantity_l =new JLabel("Quantity");
    private JLabel price_l =new JLabel("Price");
    private JButton exit_b =new JButton("EXIT");
    private JLabel chosen_journey_l =new JLabel("A");
    private JLabel chosen_quantitiy_l =new JLabel("B");
    private JLabel result_price_l =new JLabel("C");

    String trip,customerID;
    double price;
    int qua;
    
    public Bill_Window(String trip, double price ,int qua,String customerID){

        this.trip = trip;
        this.price = price;
        this.qua = qua;
        this.customerID = customerID;

        setTitle("Bill");
        setSize(440,200);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
        
        setLayout(new FlowLayout());
        
        train_l.setFont(new Font("Serif", Font.BOLD, 12));
        quantity_l.setFont(new Font("Serif", Font.BOLD, 12));
        chosen_journey_l.setFont(new Font("Serif", Font.BOLD, 12));
        chosen_quantitiy_l.setFont(new Font("Serif", Font.BOLD, 12));
        result_price_l.setFont(new Font("Serif", Font.BOLD, 12));
        exit_b.setFont(new Font("Serif", Font.BOLD, 12));
        train_l.setForeground(Color.BLUE);
        quantity_l.setForeground(Color.BLUE);
        price_l.setForeground(Color.BLUE);
        
        TitledBorder centerBorder = BorderFactory.createTitledBorder("Bill");
        centerBorder.setTitleJustification(TitledBorder.CENTER);
        Bill_p.setBorder(centerBorder);
        centerBorder.setTitleFont(new Font("Serif", Font.BOLD, 20));
      
        header_p.setLayout(new GridLayout(1,3,30,30));
        header_p.add(train_l);
        header_p.add(quantity_l);
        header_p.add(price_l);
        chosen_p.setLayout(new GridLayout(1,3,30,30));
        chosen_p.add(chosen_journey_l);
        chosen_p.add(chosen_quantitiy_l);
        chosen_p.add(result_price_l);
      
        all_p.setLayout(new BorderLayout());
        all_p.setSize(100,100);
        all_p.add(header_p,BorderLayout.NORTH);
        all_p.add(chosen_p,BorderLayout.SOUTH);
     
        Bill_p.add(all_p);
      
        button_p.setLayout(new FlowLayout(FlowLayout.CENTER));
        button_p.add(exit_b);
        
        add(Bill_p);
        add(button_p);

        chosen_journey_l.setText(trip);
        result_price_l.setText(String.valueOf(price));
        chosen_quantitiy_l.setText(String.valueOf(qua));


        exit_b.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                 
                try{
                
                FileWriter ff=new FileWriter("reservations.txt", true);
                ff.write(customerID+"\n");
                ff.write(trip+"\n");
                ff.write(qua+"\n");
                ff.write(price+"\n");
                ff.close();
                }catch(IOException e){
                
                 e.printStackTrace();
                    
                }
                System.exit(0);

                }
        });
        
    }



}

package project_train;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Show_Window extends JFrame{

    private JLabel title = new JLabel("Show Reservation");

    private JLabel enterID = new JLabel("Custoemr ID");
    private JTextField idField = new JTextField(15);
    private JButton button = new JButton("Show");

   public Show_Window(){

       setTitle("Train Reservation");

       setSize(350,250);
       setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       setLayout(new FlowLayout(FlowLayout.CENTER,40,15));
       setLocationRelativeTo(null);

       title.setFont(new Font("Serif", Font.BOLD, 24));

       add(title);
       add(enterID);
       add(idField);
       add(button);

       setVisible(true);

       button.addActionListener(new ActionListener() {
           @Override
           public void actionPerformed(ActionEvent actionEvent) {

               String customerid = idField.getText();

               boolean found = false;

               try {

                   File file = new File(("reservations.txt"));
                   Scanner scanner = new Scanner(file);

                   while (scanner.hasNextLine()) {

                       String id = scanner.nextLine();
                       String trip = scanner.nextLine();
                       String qua = scanner.nextLine();
                       String price = scanner.nextLine();


                       if (customerid.equals(id)){

                           JOptionPane.showMessageDialog(null,"       Journey Information\n\n- "+trip+"\n- "+qua+"  Tickets"+"\n\n- "+price+" SR" );
                           found = true;
                       }
                   }

                   if (!found){

                       JOptionPane.showMessageDialog(null,"This ID doesn't have Reservation");

                   }

               } catch (FileNotFoundException e) {
                   e.printStackTrace();
               }


           }
       });


    }

}

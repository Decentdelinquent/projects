package project_train;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;

public class Information_Window extends Application implements Initializable {

    public void start(Stage primaryStage) throws Exception{
        Parent root = FXMLLoader.load(getClass().getResource("javafx.fxml"));
        primaryStage.setTitle("Train");
        primaryStage.setScene(new Scene(root));
        primaryStage.show();
    }

    @FXML
    private Button confirm_res;

    @FXML
    private Label costomer_id;

    @FXML
    private Label customer_mobile;

    @FXML
    private Label customer_name;

    @FXML
    private TextField enter_id;

    @FXML
    private Label enter_info;

    @FXML
    private TextField enter_mobile;

    @FXML
    private TextField enter_name;

    @FXML
    private TextField enter_quantity;

    @FXML
    private ComboBox journey_list;

    @FXML
    private Label journy;

    @FXML
    private Label ticket_quantity;

    @Override
    public void initialize(URL location, ResourceBundle resources) {

        String[] arr = {"Jeddah to Riyadh   200 SR","Jeddah to Makkah   350 SR","Jeddah to khobar   200 SR","Almadina to Makkah   350 SR","khobar to Riyadh   150 SR"};
        journey_list.getItems().addAll(arr);

    }

    @FXML
    void confAction(ActionEvent event) {


        String customerID = enter_id.getText();
        
        try {
            
            int id = Integer.parseInt(customerID);
        
        }catch (NumberFormatException e){
            Alert warning =new Alert(Alert.AlertType.ERROR, "Required field, enter numbers only. ", ButtonType.OK);
            warning.show();
            return;
        }
   
        
        String phoneNumber = enter_mobile.getText();
            
        try {
           int mobileNo = Integer.parseInt(phoneNumber);
        }catch (NumberFormatException e){
            Alert warning =new Alert(Alert.AlertType.ERROR, "Please, enter a valid phone number. Required field.", ButtonType.OK);
            warning.show();
            return;
        }
        
        
        try{
            
          journey_list.getSelectionModel().getSelectedItem().toString();
            
            
        }catch(Exception e){
        
           Alert warning =new Alert(Alert.AlertType.ERROR, "Please, select a journey.", ButtonType.OK);
           warning.show();
           return; 
        
        }
        
        String trip = "";
        int qua = 0;
        double price = 0;

        try {
            qua = Integer.parseInt(enter_quantity.getText());
        }catch (NumberFormatException e){
            Alert warning =new Alert(Alert.AlertType.ERROR, "Please, enter a valid tickets amount", ButtonType.OK);
            warning.show();
            return;
        }
        
        if (journey_list.getSelectionModel().getSelectedItem().equals("Jeddah to Riyadh   200 SR")){

            trip = "Jeddah to Riyadh";

            price = 200 * qua;
        }else if (journey_list.getSelectionModel().getSelectedItem().equals("Jeddah to Makkah   350 SR")){

            trip = "Jeddah to Makkah";

            price = 350 * qua;
        }else if (journey_list.getSelectionModel().getSelectedItem().equals("Jeddah to khobar   200 SR")){

            trip = "Jeddah to khobar";

            price = 200 * qua;
        }else if (journey_list.getSelectionModel().getSelectedItem().equals("Almadina to Makkah   350 SR")){

            trip = "Almadina to Makkah";

            price = 350 * qua;
        }else if (journey_list.getSelectionModel().getSelectedItem().equals("khobar to Riyadh   150 SR")){

            trip = "khobar to Riyadh";

            price = 150 * qua;
        
        }
       
        
        
        Platform.exit();

        new Bill_Window(trip,price,qua,customerID);


    }

}


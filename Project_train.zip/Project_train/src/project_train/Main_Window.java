
package project_train;


import javafx.application.Application;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.JFrame;

public class Main_Window extends JFrame {
    private JPanel mainPanel=new JPanel();
    private JPanel RBpanel=new JPanel();
    private JPanel IMAGEPANEL=new JPanel();
    private JRadioButton bookRadio=new JRadioButton("Book journey");
    private JRadioButton ShowRadio=new JRadioButton("Show journey");;
    private ButtonGroup group=new ButtonGroup();
    private JLabel chooseLabel=new JLabel("Choose service");
    private JButton confirmButton=new JButton("Confirm"); 
    private JMenu menu=new JMenu("About");
    private JMenuBar menuBar=new JMenuBar();
    private JLabel hide_l=new JLabel();

    private ImageIcon im = new ImageIcon("logo.png");
    private JLabel image = new JLabel(im);
    
    
    public Main_Window(){
    
    setTitle("Train Reservation");
    setSize(350,400);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);   
    setLayout(new FlowLayout(FlowLayout.CENTER));
    
    confirmButton.setFont(new Font("Serif", Font.BOLD, 15));
    confirmButton.setForeground(Color.darkGray);
    
    buildPanel();
    buildMenuBar();
    actionListnersMethod();
    
    add(image);
    add(mainPanel);
    add(RBpanel);
    add(confirmButton);
    add(hide_l);
    getContentPane().setBackground(Color.LIGHT_GRAY);
    setLocationRelativeTo(null); 
    setVisible(true);  
    }
    
    public void buildPanel(){
    
    group.add(bookRadio);
    group.add(ShowRadio);
    
    bookRadio.setForeground(Color.BLUE);
    ShowRadio.setForeground(Color.BLUE);
    
    chooseLabel.setFont(new Font("Serif", Font.BOLD, 24));
    bookRadio.setFont(new Font("Serif", Font.BOLD, 15));
    ShowRadio.setFont(new Font("Serif", Font.BOLD, 15));
    
    bookRadio.setBackground(Color.LIGHT_GRAY);
    ShowRadio.setBackground(Color.LIGHT_GRAY);
   
    IMAGEPANEL.setBackground(Color.LIGHT_GRAY);
    mainPanel.setBackground(Color.LIGHT_GRAY);
    RBpanel.setBackground(Color.LIGHT_GRAY);
    
    mainPanel.add(menuBar);
    mainPanel.add(chooseLabel);
    RBpanel.add(bookRadio);
    RBpanel.add(ShowRadio);

    bookRadio.setSelected(true);
    
    }
    
    
    public void buildMenuBar(){
     
        
      menu.setFont(new Font("Serif", Font.BOLD, 12));  
      menu.setForeground(Color.GRAY);
      buildMenu();  
      
      menuBar.add(menu);
      setJMenuBar(menuBar);
    }
    
        public void buildMenu(){
    
     JMenuItem serviceItem=new JMenuItem("License");
     JMenuItem privacyItem=new JMenuItem("Privacy"); 
   
     serviceItem.setFont(new Font("Serif",Font.BOLD,12));
     privacyItem.setFont(new Font("Serif",Font.BOLD,12));
   
     menu.add(serviceItem);
     menu.add(privacyItem); 
     
      privacyItem.addActionListener(new ActionListener() {
         @Override
         public void actionPerformed(ActionEvent actionEvent) {
             JOptionPane.showMessageDialog(null,"You may be required to register with the Site. You agree to keep your password confidential and will be responsible for all use of your account and password. \n"
                     + "We reserve the right to remove, reclaim, or change a username you select if we determine, in our sole discretion, that such username is inappropriate, obscene, or otherwise objectionable.");
         }
     });

            serviceItem.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent actionEvent) {
                    JOptionPane.showMessageDialog(null,"Our app follows guidlines provided by the Public Transportaion Institute./n We have a legal license to operate.");
                }
            });
    
    }
    
      public void actionListnersMethod(){
      
      confirmButton.addActionListener(new ActionListener() {
         @Override
         public void actionPerformed(ActionEvent actionEvent) {

             if (bookRadio.isSelected()){

                 setVisible(false);

                 Application.launch(Information_Window.class);

             }else if (ShowRadio.isSelected()){

                    setVisible(false);

                    new Show_Window();

             }

         }
     });
 
      }
    
     public static void main(String[] args) {
        
        Main_Window mw=new Main_Window();
         
}
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gamestore;

/**

 *

 * @author layla

 */

public class sell { 

   private client seller;
   private String gameSold;
   private double usedGameCost;
   private int months=0;



   public sell (client dealer, String gameName) { // first constractor
   seller=dealer;
   gameSold=gameName;

   }


   public sell(int months) { //second constractor

     this.months=months;

   }



   public double calcFee(double cost){ // math method

       double fee=30;

       if(months>=3&&usedGameCost>30) {

       return usedGameCost=cost-fee;


       }

       else return usedGameCost=cost;

   }


  public client getSeller(){ //get method


      return seller;


  }


  public String getGame(){ //get method


  return gameSold;


  }



}

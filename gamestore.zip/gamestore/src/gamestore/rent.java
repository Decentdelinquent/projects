/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gamestore;

import java.util.*;



public class rent {

   private client renter;
   private int weeksPassed;
   private double RentCost;
   private double Fee=8;


   public rent(client renter){ //first constractor

   this.renter=renter;

   } 


   public client getRenter(){ //get method

      return renter;

  }

   public rent(int weeks){ //second constractor

       weeksPassed=weeks;

   } 

    public double calc_Rent(int weeks){ // math function


       if(weeksPassed>=3) {

       
           
       return RentCost=14.99-Fee;

       }

       else return RentCost=14.99;

   }

}
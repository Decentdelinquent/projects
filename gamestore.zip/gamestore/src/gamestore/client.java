/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gamestore;


public class client {


  private String name;
  private String phoneNumber;

  public client(String firstName, String phNo){ //first constractor

      name=firstName;
      phoneNumber=phNo;

  }


  public client(String firstName){  // second constractor

     name=firstName;

  }


   public String toupper (){ // math functoin

      return name.toUpperCase();

  } 



  public String toString(){ // Tostring function

  return "\nClient's Name: "+name.toUpperCase() +"\nPhone Number: "+phoneNumber;

  } 

  }

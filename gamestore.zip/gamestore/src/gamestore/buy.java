/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gamestore;

import java.util.*;




//done


public class buy {

   private client buyer;
   private int gameBought;
   private double price;
   private double total;
   public String greeting="\n                      Welcome to the new world!"; 

   public buy(client customer, int game) { //first constractor

       buyer=customer;
       gameBought=game;
   }

   public buy(){ //second constractor 


   }

   public buy(double price){ //third constractor

       this.price=price;

   }


   public void setTotal(double total){ //the set method

       total=0;
       this.total=total;

   }


   public void setPrice(double price){ //the set method

       price=0;
       this.price=price;

   }


   public double calcTotal(double price){ // math method

       total=total+price;

       return total;

   }


   public String toString(client customer, int game){ //ToString method

   return buyer.toString()+"\nGame number: "+gameBought+"\n";

   }

}


package gamestore;
import java.io.*; //for file
import java.util.*; //for a flexible scanner


public class Gamestore {

    
    public static void main(String[] args) throws IOException {
        
        String firstName;
        String phoneNumber;
        
        //String line; //a,b
        int Choice=0; // for the first if statment (First List)
        int Choice_B=0;//FOR BUYING choices
        int Choice_R=0;//FOR RENT choices
        double Price=0.0;
        String gameTitle;
        double sellingCost;
        String[] options={"1-Buying", "2-Selling","3-Renting","4-Reciept", "5-Exit"};
        int months=0;
        int weeks=0;
        
        //print statment to introduce the application
        Scanner keyboard = new Scanner(System.in);
        System.out.println("_________Game Store__________");
      
        System.out.println("\nPlease Enter your first name:  ");
        firstName = keyboard.nextLine();
        System.out.println("Please Enter your phone number:  ");
        phoneNumber = keyboard.nextLine(); 
        
        client customer=new client(firstName,phoneNumber);//object of class client
     
        FileWriter fw= new FileWriter("Bought.txt"); 
        PrintWriter pw = new PrintWriter(fw);
        FileWriter sw= new FileWriter("Selling.txt"); 
        PrintWriter writer = new PrintWriter(sw);
       
        FileWriter Rw= new FileWriter("Rentals.txt"); 
        PrintWriter Ret = new PrintWriter(Rw);
        
        writer.print("_________Sold_________");
        pw.printf("_____Game Store_____\n");
        Ret.printf("_____Rentals_____\n");

        
        //do while loop to choose what to do (buy, sell, or rent)
       
        do{
        System.out.println("\nOur services:");
        
        for(int i=0; i<options.length; i++) { //printing the options array
        
        System.out.println(options[i]);
            
        }
        
        System.out.println("Please enter the number for the service you want:");
        Choice=keyboard.nextInt();
        
        if(Choice==1){
        
        buy greeting=new buy();
        System.out.println(greeting.greeting);
       // File freader = new File("GamesList.txt");
        Scanner input = new Scanner(new File("GamesList.txt"));

        while (input.hasNextLine())
        {
        System.out.println(input.nextLine());
        }
        
        System.out.println("Please choose the number of the game:"); 
        Choice_B=keyboard.nextInt();
        
        switch(Choice_B){
            case 1:
                int gameNumber=1;
                buy buyer=new buy(customer, gameNumber); //object for class buy
                buy total=new buy(Price);
                pw.printf(buyer.toString(customer, gameNumber));
                pw.printf("\nTitle                                  Price\n");
                pw.printf("Mario Kart 8                           $59.99");
                Price=59.99;
                pw.printf("\nThe total is: %.2f", total.calcTotal(Price));
            break;
            case 2:
                gameNumber=2;
                buyer=new buy(customer, gameNumber);
                total=new buy(Price);
                pw.printf(buyer.toString(customer, gameNumber));
                pw.printf("\nTitle                                  Price\n");
                pw.printf("Super Mario Odyssey                    $45.99");
                Price=45.99;
                pw.printf("\nThe total is: %.2f", total.calcTotal(Price));
                break;
            case 3:
                gameNumber=3;
                buyer=new buy(customer, gameNumber);
                total=new buy(Price);
                pw.printf(buyer.toString(customer, gameNumber));
                pw.printf("\nTitle                                  Price\n");
                pw.printf("Animal Crossing                        $59.99");
                Price=59.99;
                pw.printf("\nThe total is: %.2f", total.calcTotal(Price));
                break;
            case 4:
                gameNumber=4;
                buyer=new buy(customer, gameNumber);
                total=new buy(Price);
                pw.printf(buyer.toString(customer, gameNumber));
                pw.printf("\nTitle                                  Price\n");
                pw.printf("Kena:Bridge of Spirits                 $31.49");
                Price=31.49;
                pw.printf("\nThe total is: %.2f", total.calcTotal(Price));
                break;
            case 5:
                gameNumber=5;
                buyer=new buy(customer, gameNumber);
                total=new buy(Price);
                pw.printf(buyer.toString(customer, gameNumber));
                pw.printf("\nTitle                                  Price\n");
                pw.printf("Horizon Forbidden West                 $79.99");
                Price=79.99;
                pw.printf("\nThe total is: %.2f", total.calcTotal(Price));
                break;
            case 6:
                gameNumber=6;
                buyer=new buy(customer, gameNumber);
                total=new buy(Price);
                pw.printf(buyer.toString(customer, gameNumber));
                pw.printf("\nTitle                                  Price\n");
                pw.printf("Spider-Man: Miles Morales              $59.99");
                Price=59.99;
                pw.printf("\nThe total is: %.2f", total.calcTotal(Price));
                break;
            case 7:
                gameNumber=7;
                buyer=new buy(customer, gameNumber);
                total=new buy(Price);
                pw.printf(buyer.toString(customer, gameNumber));
                pw.printf("\nTitle                                  Price\n");
                pw.printf("Lost in Random                         $37.00");
                Price=37.00;
                pw.printf("\nThe total is: %.2f", total.calcTotal(Price));
                break;
            case 8:
                gameNumber=8;
                buyer=new buy(customer, gameNumber);
                total=new buy(Price);
                pw.printf(buyer.toString(customer, gameNumber));
                pw.printf("\nTitle                                  Price\n");
                pw.printf("Minecraft                              $19.99");
                pw.printf("\nThe total is: %.2f", total.calcTotal(Price));
                break;
            case 9:
                gameNumber=9;
                buyer=new buy(customer, gameNumber);
                total=new buy(Price);
                pw.printf(buyer.toString(customer, gameNumber));
                pw.printf("\nTitle                                  Price\n");
                pw.printf("Crash Bandicoot                        $39.99");
                Price=39.99;
                pw.printf("\nThe total is: %.2f", total.calcTotal(Price));
                break;
            case 10:
                gameNumber=10;
                buyer=new buy(customer, gameNumber);
                total=new buy(Price);
                pw.printf(buyer.toString(customer, gameNumber));
                pw.printf("\nTitle                                  Price\n");
                pw.printf("Spyro Reignited Trilogy                $39.99");
                Price=39.99;
                pw.printf("\nThe total is: %.2f", total.calcTotal(Price));
                break;
            case 11:
                gameNumber=11;
                buyer=new buy(customer, gameNumber);
                total=new buy(Price);
                pw.printf(buyer.toString(customer, gameNumber));
                pw.printf("\nTitle                                  Price\n");
                pw.printf("ELDEN RING                             $59.99");
                Price=59.99;
                pw.printf("\nThe total is: %.2f", total.calcTotal(Price));
                break;
            case 12:
               gameNumber=12;
                buyer=new buy(customer, gameNumber);
                total=new buy(Price);
                pw.printf(buyer.toString(customer, gameNumber));
                pw.printf("\nTitle                                  Price\n");
                pw.printf("Overwatch                              $59.99");
                Price=59.99;
                pw.printf("\nThe total is: %.2f", total.calcTotal(Price));
                break;
                
            case 13:
                gameNumber=13;
                buyer=new buy(customer, gameNumber);
                total=new buy(Price);
                pw.printf(buyer.toString(customer, gameNumber));
                pw.printf("\nTitle                                  Price\n");
                pw.printf("Among Us                               $4.80");
                Price=4.80;
                pw.printf("\nThe total is: %.2f", total.calcTotal(Price));
                
                break;
            default:
            System.out.println("sorry not available");  
        }
        
                
        }
        
        else if(Choice==2){ 
            
        keyboard.nextLine();
        System.out.println("Please Enter game title: ");
        gameTitle= keyboard.nextLine();
 
        client upper=new client(firstName);
        upper . toupper ();
        sell selling=new sell(customer,gameTitle);
        
        System.out.println("Please Enter the selling cost:  ");
        sellingCost = keyboard.nextDouble();
            
        System.out.println("How long did you use this game (in months)?");
        months=keyboard.nextInt();
        sell fee=new sell(months);
        double soldAt=fee.calcFee(sellingCost);
       
       writer.println("\n"+selling.getSeller());//to print in the selling file
       writer.println("Game: "+selling.getGame());
       writer.println("For: "+soldAt);
       
       writer.close();//closing the file
        }
        else if(Choice==3){ 
         
            int r=0;
            System.out.println("Do you want to:+\n 1. Rent a game\n or \n2. Return a game?");
            r=keyboard.nextInt();
            
            switch(r) { //switch for rent options
            
               case 1:
               rent renter=new rent(customer);
               Scanner input = new Scanner(new File("RentalsList.txt"));


               while (input.hasNextLine())

               {

               System.out.println(input.nextLine());

                }

               System.out.println("Please choose the number of the game:"); 
               Choice_R=keyboard.nextInt();

               switch(Choice_R) {
                
                case 1:
                 
                Ret.println("\nTitle: Cris Tales   Price: $14.99\n");    
                Ret.println(renter.getRenter());
                
               
                break;
                
                case 2:
                    
                Ret.printf("\nTitle: Little Nightmares   Price: $14.99\n");    
                Ret.println(renter.getRenter());
                
                break;
                
                case 3:
                    
                Ret.printf("\nTitle: Lost in Random   Price: $14.99\n");    
                Ret.println(renter.getRenter());
                
                
                break;
                
                case 4:
                    
                Ret.printf("\nTitle: Solar Ash    Price: $14.99\n");    
                Ret.println(renter.getRenter());
                
                
                break;
                    
                case 5:    
                
                Ret.printf("\nTitle: Don't Starve Together   Price: $14.99\n");    
                Ret.println(renter.getRenter());
                
                
                break;
               }
               Ret.close();
               break;
                 
                
            case 2:    
            
       System.out.println("please enter the weeks you Rented, there will be an 8$ fee in case you rented it for more than 3 weeks:");
       weeks=keyboard.nextInt();
       rent Rentcost = new rent(weeks);
       System.out.println("Here's your money: "+Rentcost.calc_Rent(weeks));
        break;
            }

        }    
                
else if(Choice==4){

       keyboard.nextLine();   
      
       Scanner input_b = new Scanner(new File("Bought.txt"));

       while (input_b.hasNextLine())
       {

       System.out.println(input_b.nextLine());

       }

       Scanner input_S = new Scanner(new File("Selling.txt"));

       while (input_S.hasNextLine())
       {

       System.out.println(input_S.nextLine());

       }
       
       Scanner input_R = new Scanner(new File("Rentals.txt"));

       while (input_R.hasNextLine())
       {

       System.out.println(input_R.nextLine());

       }

}
else if(Choice==5){

        System.out.println("Thank you for visiting");
        }
        
        else if(Choice>5){
        System.out.println("Sorry not an available choice!");
        System.out.println("choose again");     
        }
      
 
 }while(Choice!=5);
     writer.close();
     pw.close();
     Ret.close();

    
    
    }
}


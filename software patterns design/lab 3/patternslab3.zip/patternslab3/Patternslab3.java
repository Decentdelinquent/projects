/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package patternslab3;

/**
 *
 * @author layla
 */
public class Patternslab3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        DocumentTemplate docTempPrototype= new Article();
        DocumentTemplate thinkPiece=docTempPrototype.clone();
        
        thinkPiece.createDoc();
        thinkPiece.editTemplate();
        
        
        gameLevel levelPrototype1= new iceLevel();
        gameLevel level1=levelPrototype1.clone();
        
        level1.addObstacles();
        level1.pickTerrain();
        level1.placeEnemy();
        
        gameLevel levelPrototype2= new lavaLevel();
        gameLevel level2=levelPrototype2.clone();
        
        level2.addObstacles();
        level2.pickTerrain();
        level2.placeEnemy();
    }
    
}

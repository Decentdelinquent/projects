/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package patternslab3;

/**
 *
 * @author layla
 */
interface DocumentTemplate extends Cloneable {
   
   public DocumentTemplate clone();
   public void createDoc();
   public void editTemplate();
}

class Article implements DocumentTemplate{
    
    @Override
    public DocumentTemplate clone(){
    
    return new Article();
            
    }  
    
    @Override
    public void createDoc(){
    
        System.out.println("An article template is created.");
    
    }
    
    @Override
    public void editTemplate(){
    
        System.out.println("changing colors, font, and borders.");
    
    }
    
}

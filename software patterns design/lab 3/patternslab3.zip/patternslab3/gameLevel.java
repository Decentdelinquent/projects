/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package patternslab3;

/**
 *
 * @author layla
 */
public interface gameLevel extends Cloneable {
    public gameLevel clone ();
    public void addObstacles();
    public void placeEnemy();
    public void pickTerrain();
}

class iceLevel implements gameLevel{

    @Override
    public gameLevel clone(){return new iceLevel();};
    @Override
    public void addObstacles(){System.out.println("adding glaciers.");};
    @Override
    public void placeEnemy(){System.out.println("deploying polar bears.");};
    @Override
    public void pickTerrain(){System.out.println("covering area with snow.");};

}

class lavaLevel implements gameLevel{

    @Override
    public gameLevel clone(){return new lavaLevel();};
    @Override
    public void addObstacles(){System.out.println("adding molten lava rocks.");};
    @Override
    public void placeEnemy(){System.out.println("deploying rock creatures.");};
    @Override
    public void pickTerrain(){System.out.println("covering area with lava and obsedian.");};

}
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package patternslab1;

/**
 *
 * @author layla
 */
public class Animal {
    
    void makeSound(){System.out.println("this the sound of a wild animal...");}
    void showImage(){System.out.println("this is what a wild animal looks like...");}
    void giveFood(){System.out.println("feeding animal...");}
}

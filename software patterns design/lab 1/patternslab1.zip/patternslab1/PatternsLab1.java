/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package patternslab1;

/**
 *
 * @author layla
 */
public class PatternsLab1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        System.out.println("task 1");
        Drawable c=new Circle();
        c.draw();
        
        Drawable s=new Square();
        s.draw();
        
        System.out.println("task 2");
        Vehicle cr=new Car();
        Vehicle bscl=new Bicycle();
        
        Vehicle[] vcle = new Vehicle[2];
        
        vcle[0]=cr;
        vcle[1]=bscl;
        
        for(Vehicle arr: vcle){
        
        cr.start();
        bscl.start();
        }
        
       System.out.println("task 3");
        
        Manager m=new Manager();
        System.out.println("manager salary is: "+m.calculateSalary(10.50, 8));  
        Developer d=new Developer();
        System.out.println("developer salary is: "+d.calculateSalary(8));
        
        System.out.println("task 4");
        
        MathOperations mo = new MathOperations();
        mo.myOperation(3.00, 4.00);
        
        AdvancedMathOperations amo= new AdvancedMathOperations();
        amo.myOperation(3.00, 4.00);
        
        System.out.println("task 5");
        Animal ape=new Monkey();
        Animal bigCat=new Lion();
        Animal peanutEater=new Elephant();
        
        Animal[] array=new Animal[3];
        
        array[0]=ape;
        array[1]=bigCat;
        array[2]=peanutEater;
        
        for(Animal y: array){
        
        ape.makeSound();
        bigCat.showImage();
        peanutEater.giveFood();
        }
    }
    
}

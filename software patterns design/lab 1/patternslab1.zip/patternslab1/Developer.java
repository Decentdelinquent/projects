/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package patternslab1;

/**
 *
 * @author layla
 */
public class Developer extends Employee {
    
    double calculateSalary(double workingHours){
    
        double salary;
        salary=7.25*workingHours*52;
        
    return salary;}
}

package patternslab1;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author layla
 */
public class MathOperations {
    
    void myOperation (int a, int b){
    System.out.println("addition"+(a+b));
    }
    
    void myOperation (double x, double y){
    System.out.println("multiplication: "+(x*y));
    }
    
     void myOperation (float a, float b){
    System.out.println("subtraction"+(a-b));
    }
}

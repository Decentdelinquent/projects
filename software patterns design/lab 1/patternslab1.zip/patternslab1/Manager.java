/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package patternslab1;

/**
 *
 * @author layla
 */
public class Manager extends Employee {
    
    double calculateSalary(double hourlyPay, double workingHours){
    
        double salary;
        salary=hourlyPay*workingHours*52*(100/10);
        
    return salary;}
}

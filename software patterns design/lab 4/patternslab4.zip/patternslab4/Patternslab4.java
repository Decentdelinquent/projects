/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package patternslab4;

import java.util.Scanner;

/**
 *
 * @author layla
 */
public class Patternslab4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
      System.out.println("welcome! pick the meal you like.");
      System.out.println("1. vegan meal \n2. vegeterian meal \n3. regular meal");
      
      
      Scanner scnr=new Scanner(System.in);
      int choice=scnr.nextInt();
      
      switch(choice){
    
          case 1:
                  mealMaker VGNmeal=new veganMeal();
                  mealCustmizer mealCreator=new mealCustmizer(VGNmeal);
                  mealCreator.makeMeal();
                  Meal firstMeal=mealCreator.getMeal();
                  System.out.println("your meal is done! enjoy your menu of:");
                   System.out.println("Appetizer:"+firstMeal.getApptzr());
                    System.out.println("Main course:"+firstMeal.getMnCrs());
                     System.out.println("side dish:"+firstMeal.getSdDsh());
                      System.out.println("desert:"+firstMeal.getDsrt());
                      break;
          case 2:
               mealMaker VGTRNmeal=new vegeterianMeal();
                  mealCustmizer mealCreator2=new mealCustmizer(VGTRNmeal);
                  mealCreator2.makeMeal();
                  Meal secondMeal=mealCreator2.getMeal();
                  System.out.println("your meal is done! enjoy your menu of:");
                   System.out.println("Appetizer:"+secondMeal.getApptzr());
                    System.out.println("Main course:"+secondMeal.getMnCrs());
                     System.out.println("side dish:"+secondMeal.getSdDsh());
                      System.out.println("desert:"+secondMeal.getDsrt());
                      break;
          case 3:
               mealMaker RGLRmeal=new regularMeal();
                  mealCustmizer mealCreator3=new mealCustmizer(RGLRmeal);
                  mealCreator3.makeMeal();
                  Meal thirdMeal=mealCreator3.getMeal();
                  System.out.println("your meal is done! enjoy your menu of:");
                   System.out.println("Appetizer:"+thirdMeal.getApptzr());
                    System.out.println("Main course:"+thirdMeal.getMnCrs());
                     System.out.println("side dish:"+thirdMeal.getSdDsh());
                      System.out.println("desert:"+thirdMeal.getDsrt());
                      break;
          default:
              break;
    }
     System.out.println("\n assignemnt 2\n");
     
      VehicleFactory car=new CarFactory();
      car.createVehicle().assemble();
      
      VehicleFactory truck=new TruckFactory();
      truck.createVehicle().assemble();
      
      VehicleFactory motorcycle=new MotorcycleFactory();
      motorcycle.createVehicle().assemble();
      
    }
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package patternslab4;

/**
 *
 * @author layla
 */
public class Meal {
     private String appetizer;
     private String mainCourse;
     private String sideDish; 
     private String dessert;
     
     public void setApptzr(String aptzr){appetizer=aptzr;}
     public void setMnCrs(String mnCrs){mainCourse=mnCrs;}
     public void setSdDsh(String SdDsh){sideDish=SdDsh;}
     public void setDsrt(String dsrt){dessert=dsrt;}
     
     public String getApptzr(){return appetizer;}
     public String getMnCrs(){return mainCourse;}
     public String getSdDsh(){return sideDish;}
     public String getDsrt(){return dessert;}
}

interface mealMaker{

public Meal getMeal();
 void setAppetizers();
 void setMainCourse();
 void setSideDish();
 void setDessert();
}

class veganMeal implements mealMaker{

private Meal meal;
public veganMeal(){this.meal=new Meal();}

    @Override
    public void setAppetizers() {
      meal.setApptzr("hummus");
    }

    @Override
    public void setMainCourse() {
       meal.setMnCrs("BBQ nushrooms");
    }

    @Override
    public void setSideDish() {
        meal.setSdDsh("chinese cucunber salad");
    }

    @Override
    public void setDessert() {
       meal.setDsrt("peanut butter and banana oat chocolate cake");
    }

    @Override
    public Meal getMeal(){return this.meal;};

}

class vegeterianMeal implements mealMaker{

private Meal meal;
public vegeterianMeal(){this.meal=new Meal();}

    @Override
    public void setAppetizers() {
      meal.setApptzr("garlic bread");
    }

    @Override
    public void setMainCourse() {
       meal.setMnCrs("carbonara");
    }

    @Override
    public void setSideDish() {
        meal.setSdDsh("fried zucchini");
    }

    @Override
    public void setDessert() {
       meal.setDsrt("strawberty shortcake");
    }

    @Override
    public Meal getMeal(){return this.meal;};

}

class regularMeal implements mealMaker{

private Meal meal;
public regularMeal(){this.meal=new Meal();}

    @Override
    public void setAppetizers() {
      meal.setApptzr("swiss cheese");
    }

    @Override
    public void setMainCourse() {
       meal.setMnCrs("ragu alla bolognese");
    }

    @Override
    public void setSideDish() {
        meal.setSdDsh("Ricotta Chicken Croquettes");
    }

    @Override
    public void setDessert() {
       meal.setDsrt("teramisu");
    }

    @Override
    public Meal getMeal(){return this.meal;};

}

class mealCustmizer {

private mealMaker mealMenu;

public mealCustmizer(mealMaker menu){
    this.mealMenu=menu;
}

public Meal getMeal(){

    return this.mealMenu.getMeal();
}

public void makeMeal(){

    this.mealMenu.setAppetizers();
    this.mealMenu.setMainCourse();
    this.mealMenu.setSideDish();
    this.mealMenu.setDessert();

}
}
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package patternslab4;

public interface Vehicle {
    void assemble();
}

class Car implements Vehicle{

    @Override
   public void assemble(){System.out.println("assembing car...");};

}

class Truck implements Vehicle{

@Override
public void assemble(){System.out.println("assembling truck...");}
}

class Motorcycle implements Vehicle{
@Override
public void assemble(){System.out.println("assembling motorcycle...");}
}

interface VehicleFactory{

    Vehicle createVehicle();

}

class CarFactory implements VehicleFactory{

@Override
public Vehicle createVehicle(){return new Car();}
}

class TruckFactory implements VehicleFactory{

@Override
public Vehicle createVehicle(){return new Truck();}
}

class MotorcycleFactory implements VehicleFactory{

@Override
public Vehicle createVehicle(){return new Motorcycle();}
}
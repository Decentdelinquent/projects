/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package patternlab2;

/**
 *
 * @author layla
 */
public class Counter {
    private static Counter instance=null;
    int counter;
    private Counter(){
    //constructor
    }
    
    public static Counter getInstance(){
    
    if(instance==null){
        instance=new Counter();
    }
    
    return instance;
    }
    
    public int incrementCount(){
    
        return counter++;
    
    }
}

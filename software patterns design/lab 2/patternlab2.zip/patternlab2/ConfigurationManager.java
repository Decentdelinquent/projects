/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package patternlab2;

/**
 *
 * @author layla
 */
public class ConfigurationManager {
    private static ConfigurationManager instance = null ;
    private String langSettings;
    private String defaultTheme;
   private ConfigurationManager(){}
   
   public static ConfigurationManager getInstance(){
   
       if(instance==null){
       instance=new ConfigurationManager();
       }
       
   return instance;
   }
   
   public String setDefaultLanguage(){
   
   return langSettings="The default is English.";
   }
   
   public String setDefaultTheme(){
   
   return defaultTheme="The default is light mode.";
   }
   
   
}

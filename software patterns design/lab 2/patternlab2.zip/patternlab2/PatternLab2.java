/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package patternlab2;

/**
 *
 * @author layla
 */
public class PatternLab2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Counter cntr=Counter.getInstance();
       System.out.println(cntr.incrementCount());
       System.out.println(cntr.incrementCount());
       System.out.println(cntr.incrementCount());
       
       ConfigurationManager CM=ConfigurationManager.getInstance();
       
       System.out.println(CM.setDefaultLanguage());
       System.out.println(CM.setDefaultTheme());
    }
    
    
    
}

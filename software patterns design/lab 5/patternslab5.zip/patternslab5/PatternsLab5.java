/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package patternslab5;

import java.util.Scanner;

/**
 *
 * @author layla
 */
public class PatternsLab5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        paymentsProcessor payPalGateway=new paypalAdapter();
        
        System.out.println("processing payment...");
        payPalGateway.processPayment();
        
         paymentsProcessor stcPayGateway=new stcpayAdapter();
        
        System.out.println("processing payment...");
        stcPayGateway.processPayment();
        
         paymentsProcessor samsungPayGateway=new SamsungPayAdapter();
        
        System.out.println("processing payment...");
        samsungPayGateway.processPayment();
        
        //lab 5 assignment 2
        
        System.out.println("\n \n");
        System.out.println("""
                           welcome to the hosipital system. enter "File No." to check a medical record.
                            enter a name to check a patient's info 
                            enter a date in the format dd/mm/yyyy to schedule an appointment.""");
        
        Scanner scnr=new Scanner(System.in);
        String input;
        input=scnr.nextLine();
        
        HospitalManagmentFacade Facade=new HospitalManagmentFacade(input);
    }
    
}

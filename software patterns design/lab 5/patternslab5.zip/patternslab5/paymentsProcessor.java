/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package patternslab5;

public interface paymentsProcessor {
    void processPayment();
}

class paypal{


   public void charge(){
   
       System.out.println("Paypal is accessing your card to draw the amount...");
   } 


}


class stcPay {


public void authurizePayment(){
   
       System.out.println("stcPay is charging the amount off your account...");
   } 

}

class SamsungPay{


public void makeTransiction(){
   
       System.out.println("SamsungPay has drawn the amount from your card...");
   } 

}


class paypalAdapter implements paymentsProcessor{

   paypal PmntPrcsr;

   @Override
   public void processPayment(){

    PmntPrcsr=new paypal();
    PmntPrcsr.charge();

}
}

class stcpayAdapter implements paymentsProcessor{

   stcPay PmntPrcsr;

   @Override
   public void processPayment(){

    PmntPrcsr=new stcPay();
    PmntPrcsr.authurizePayment();

}
}

class SamsungPayAdapter implements paymentsProcessor{

   SamsungPay PmntPrcsr;

   @Override
   public void processPayment(){

    PmntPrcsr=new SamsungPay();
    PmntPrcsr.makeTransiction();

}
}
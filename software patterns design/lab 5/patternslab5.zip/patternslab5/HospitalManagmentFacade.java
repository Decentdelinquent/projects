/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package patternslab5;

class PatientInfoSubsystem{

public void retreivePatientInfo(){
    System.out.println("retreiving patient info...");
}
}

class AppointmentSubsystem{

  public void scheduleAppointment(){
  
      System.out.println("scheduling appointment...");
  }
}

class MedicalRecordSubsystem{

   public void manageMedicalRecords(){
    
       System.out.println("managing medical record...");
    }
}

public class HospitalManagmentFacade {
    
    private MedicalRecordSubsystem medRec;
    private AppointmentSubsystem appntmnt;
    private PatientInfoSubsystem ptntInf;
    
    HospitalManagmentFacade(String input){
    
    
        medRec=new MedicalRecordSubsystem();
        appntmnt=new AppointmentSubsystem();
        ptntInf=new PatientInfoSubsystem();
        
        if(input.startsWith("File No.") || input.startsWith("file no.")){
        
        medRec.manageMedicalRecords();
        }
        if(input.contains("/")){
        appntmnt.scheduleAppointment();
        }
        if(!input.contains("/") && !input.startsWith("File No.") && !input.startsWith("file no.")){
        ptntInf.retreivePatientInfo();
        }
    }
    
}
